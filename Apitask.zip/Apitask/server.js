const express = require("express")
const bodyparser = require("body-parser")
const morgan = require("morgan")
const dotenv = require('dotenv')

const app= express()

// connecting mongodb
const connectDB = require('./server/database/connection')
app.use(bodyparser.urlencoded({extended:true}))

dotenv.config({path: 'config.env'})
const PORT = process.env.PORT||4000

app.use(morgan('dev'))

app.get("/",(req,res)=>{
    res.send("hello from the server")
})

// mongodb connected
connectDB();

// app.use(bodyparser.json())
app.use('/',require('./server/route/router'))


app.listen(PORT,(req,res)=>{
    console.log("server start",PORT)
})