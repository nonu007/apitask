const userdemand = require('../model/model')

//  create and save new user
exports.create = (req,res)=>{
    
    // creating callback function
    if(!req.body){
        res.status(400).send({message : "data or content cannot empty"})
        return;
    }
                
   //  create new user 
    const userstore = new userdemand({

            item : req.body.item,
            price : req.body.price,
            quantity : req.body.quantity
        })
            
        userstore.save(userstore)
        .then(data=>{
         res.send(data)
            })
        
        .catch(err =>{
            res.status(500).send({message : "some error occured"})
        })
            

}

   
//  find or read user detail
exports.find =(req,res) =>{
    if(req.body.id){
        const id =req.body.id

        userdemand.findById(id)
        .then(data=>{
            if(!data){
                res.status(404).send({message : 'user are not available'})
            }
            else{
                res.send(data)
            }
        })
        .catch(err =>{
            res.status(500).send({message : `user not matched by ${id}`})
        })
    }
    else {
        userdemand.find()
        .then(userdb=>{
            res.send(userdb)
        })
        .catch(err=>{
            res.status(500).send({message : 'some  error are occured'})
        })
    }
}

//  update by user id 
exports.update = (req,res) =>{
    if(req.body){
        return  res.status(400).send({message : `cannot update user with  ${id}`})
    }
     const id = req.params.id;

     userdemand.findByIdAndUpdate(id,req.body,{usefindandmodify:false })

     .then(data =>{
         if(!data){
              res.status(404).send({message : 'user id did not match'})
         }
         else{
             res.send(data)
         }
     })

     .catch(err=>{
         res.status(500).send({message:'some error are occured'})
     })
}
    // delete user by id 
    exports.delete = (req,res) =>{
        const id = req.params.id
        userdemand.findByIdAndDelete(id) 
        .then(data =>{
            if(!data){
                res.status(404).send({message : 'connot delete user or maybe id is incorrect'})
            }
            else{
                res.send({message:"user deleted successfully"})
            }
        })
        .catch(err=>{
            res.status(500).send({message:"some error are occured"})
        })
    }