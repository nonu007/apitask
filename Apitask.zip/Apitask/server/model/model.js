const mongoose =  require('mongoose')

const schema = new mongoose.Schema({
    
    item : {
        type : String,
        required : true,
    },
    
    price : {
        type : Number,
        required : true,
    },
    
     quantity : {
        type : Number,
        required : true,
    },

    date :  {
    type : Date,
    default : Date.now()
    }
}),
//  userdemand is our class name 
//  userdb is our collection name that will be shown in  our database
userdemand = mongoose.model('userdb',schema)

module.exports = userdemand;



























