

// exports.indexRouter = (req,res)=>{
//     res.render('index')
// }